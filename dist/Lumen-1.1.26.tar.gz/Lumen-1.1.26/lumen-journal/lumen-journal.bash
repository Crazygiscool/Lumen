# Basic placeholder completion
_complete_lumen_journal() {
    COMPREPLY=()
}
complete -F _complete_lumen_journal lumen-journal
